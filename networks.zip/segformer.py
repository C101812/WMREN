from collections import OrderedDict
import numpy as np
from HWD import HWD

import torch
import torch.nn as nn
import torch.nn.functional as F


class ConvModule(nn.Module):#3*3
    def __init__(self, c1, c2):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, 3, 1, 1, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.activate = nn.ReLU(True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.activate(self.bn(self.conv(x)))

class DWConv(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dwconv = nn.Conv2d(dim, dim, 3, 1, 1, groups=dim)  # 3为kernal大小，

    def forward(self, x: torch.Tensor, H, W) -> torch.Tensor:
        B, N, C = x.shape
        tx = x.transpose(1, 2).view(B, C, H, W)
        conv_x = self.dwconv(tx)
        return conv_x.flatten(2).transpose(1, 2)


class PreActBottleneck(nn.Module):
    """Pre-activation (v2) bottleneck block.
    """

    def __init__(self, cin, cout=None, cmid=None, stride=1):
        super().__init__()
        cout = cout or cin
        cmid = cmid or cout // 4

        self.bn1 = nn.BatchNorm2d(cmid)
        self.conv1 = nn.Conv2d(cin, cmid, 1, 1, 0, bias=False)
        self.bn2 = nn.BatchNorm2d(cmid)
        self.conv2 = nn.Conv2d(cmid, cmid, 3, 1, 1, bias=False)  # Original code has it on conv1!!
        self.bn3 = nn.BatchNorm2d(cout)
        self.conv3 = nn.Conv2d(cmid, cout, 1, 1, 0, bias=False)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        residual = x

        y = self.relu(self.bn1(self.conv1(x)))
        y = self.relu(self.bn2(self.conv2(y)))
        y = self.bn3(self.conv3(y))

        y = residual + y

        return y
class down(nn.Module):
    def __init__(self, cin, cout):
        super().__init__()
        self.root1 = nn.Sequential(OrderedDict([
            ('conv', nn.Conv2d(cin, cout, kernel_size=3, stride=2, bias=False, padding=1)),
            ('gn', nn.BatchNorm2d(cout)),
        ]))

    def forward(self, x):
        x1 = self.root1(x)

        return x1

class Resnet1(nn.Module):
    def __init__(self, block_units=None, width_factor=1):
        super().__init__()
        width = int(64 * width_factor)
        self.width = width  # width=64

        self.root = nn.Sequential(OrderedDict([
            ('conv', nn.Conv2d(3, 64, kernel_size=7, stride=2, bias=False, padding=3)),
            ('gn', nn.BatchNorm2d(64)),
        ]))

        self.body = nn.Sequential(OrderedDict([  # 这里结构和resnet不太一样
            ('block1/', nn.Sequential(OrderedDict(
                [(f'unit{i:d}/', PreActBottleneck(cin=64, cout=64, cmid=16)) for i in
                 range(3)],  # 1+2 256
            )))]))

    def forward(self, x):
        x = self.root(x)  # 统一过一个7x7
        x = self.body[0](x)  #

        return x
class Resnet2(nn.Module):
    def __init__(self, block_units=None, width_factor=1):
        super().__init__()
        width = int(64 * width_factor)
        self.width = width  # width=64
        self.root = down(64, 128)
        self.body = nn.Sequential(OrderedDict([  # 这里结构和resnet不太一样
            ('block2/', nn.Sequential(OrderedDict(
                [(f'unit{i:d}/', PreActBottleneck(cin=128, cout=128, cmid=32)) for i in
                 range(3)],  # 1+3 512
            )))]))

    def forward(self, x):
        x = self.root(x)  # 统一过一个7x7
        x = self.body[0](x)  #

        return x


class Resnet3(nn.Module):
    def __init__(self, block_units=None, width_factor=1):
        super().__init__()
        width = int(64 * width_factor)
        self.width = width  # width=64
        self.root = down(128, 320)
        self.body = nn.Sequential(OrderedDict([  # 这里结构和resnet不太一样
            ('block3/', nn.Sequential(OrderedDict(
                [(f'unit{i:d}/', PreActBottleneck(cin=320, cout=320, cmid=80)) for i in
                 range(9)],  # 1+5 1024
            )))]))

    def forward(self, x):
        x = self.root(x)  # 统一过一个7x7
        x = self.body[0](x)  #

        return x


class Resnet4(nn.Module):
    def __init__(self, block_units=None, width_factor=1):
        super().__init__()
        width = int(64 * width_factor)
        self.width = width  # width=64
        self.root = down(320, 512)
        self.body = nn.Sequential(OrderedDict([  # 这里结构和resnet不太一样
            ('block4/', nn.Sequential(OrderedDict(
                [(f'unit{i:d}/', PreActBottleneck(cin=512, cout=512, cmid=128)) for i in
                 range(3)],  # 1+2
            )))]))

    def forward(self, x):
        x = self.root(x)  # 统一过一个7x7
        x = self.body[0](x)  #

        return x

class MiT(nn.Module):  # 编码层，dims, layers = [[64, 128, 320, 512], [2, 2, 2, 2]]
    def __init__(self, image_size, dims, layers, token_mlp='mix_skip'):
        super().__init__()

        # patch_embed
        self.resnet1 =Resnet1()
        self.resnet2 =Resnet2()
        self.resnet3 = Resnet3()
        self.resnet4 = Resnet4()
        self.HWD1=HWD(3,64)
        self.HWD2=HWD(64,128)
        self.HWD3=HWD(128,320)
        self.HWD4=HWD(320,512)

        self.fusion1=F1(64)
        self.fusion2 =F1(128)
        self.fusion3 =F1(320)
        self.fusion4 =F1(512)

        self.block1 = MLKA(64)
        self.block2 = MLKA(128)
        self.block3 = MLKA(320)
        self.block4 = MLKA(512)

        self.mlp1=MLP(64)
        self.mlp2=MLP(128)
        self.mlp3=MLP(320)
        self.mlp4=MLP(512)


    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B = x.shape[0]
        outs = []

        # stage 1
        # x=self.Model(x)

        x_haar = self.HWD1(x)
        x_res=self.resnet1(x)
        x=self.fusion1(x_res,x_haar)
        x=self.block1(x)#捕捉全局
        x=self.mlp1(x)#感知机
        outs.append(x)  #24 64 56 56

        # stage 2
        x_haar = self.HWD2(x)
        x_res=self.resnet2(x)
        x = self.fusion2(x_res,x_haar)
        x = self.block2(x)
        x=self.mlp2(x)
        outs.append(x)  #24 64 56 56

        # stage 3
        x_haar = self.HWD3(x)
        x_res=self.resnet3(x)
        x = self.fusion3(x_res,x_haar)
        x = self.block3(x)
        x=self.mlp3(x)
        outs.append(x)  #24 64 56 56

        # stage 4
        x_haar = self.HWD4(x)
        x_res=self.resnet4(x)
        x = self.fusion4(x_res,x_haar)
        x = self.block4(x)
        x=self.mlp4(x)
        outs.append(x)  #24 64 56 56
        return outs


segformer_settings = {
    'B0': [[32, 64, 160, 256], [2, 2, 2, 2], 256],  # [channel dimensions, num encoder layers, embed dim]
    'B1': [[64, 128, 320, 512], [2, 2, 2, 2], 256],
    'B2': [[64, 128, 320, 512], [3, 4, 6, 3], 768],
    'B3': [[64, 128, 320, 512], [3, 4, 18, 3], 768],
    'B4': [[64, 128, 320, 512], [3, 8, 27, 3], 768],
    'B5': [[64, 128, 320, 512], [3, 6, 40, 3], 768]
}
import torch
import torch.nn as nn
import torch.nn.functional as F

class ConvModule(nn.Module):
    def __init__(self, c1, c2):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, 1)
        self.bn = nn.BatchNorm2d(c2)
        self.activate = nn.ReLU(True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.activate(self.bn(self.conv(x)))

class LayerNorm(nn.Module):
    def __init__(self, normalized_shape, eps=1e-6, data_format="channels_last"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.data_format = data_format
        if self.data_format not in ["channels_last", "channels_first"]:
            raise NotImplementedError
        self.normalized_shape = (normalized_shape,)

    def forward(self, x):
        if self.data_format == "channels_last":
            return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        elif self.data_format == "channels_first":
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            x = self.weight[:, None, None] * x + self.bias[:, None, None]
            return x

class MLKA(nn.Module):
    def __init__(self, n_feats):
        super().__init__()
        i_feats = 2 * n_feats
        self.norm = LayerNorm(n_feats, data_format='channels_first')
        self.proj_first = nn.Sequential(nn.Conv2d(n_feats, i_feats, 1, 1, 0))

        self.LKA3 = nn.Sequential(
            nn.Conv2d(n_feats // 8, n_feats // 8, 3, 1, 1, groups=n_feats // 8),
            nn.Conv2d(n_feats // 8, n_feats // 8, 5, 1, (5 // 2) * 2, groups=n_feats // 8, dilation=2),
            nn.Conv2d(n_feats // 8, n_feats // 8, 1, 1, 0)
        )
        self.X3 = nn.Conv2d(n_feats // 8, n_feats // 8, 3, 1, 1, groups=n_feats // 8)

        self.LKA5 = nn.Sequential(
            nn.Conv2d(n_feats // 2, n_feats // 2, 5, 1, 5 // 2, groups=n_feats // 2),
            nn.Conv2d(n_feats // 2, n_feats // 2, 7, 1, (7 // 2) * 3, groups=n_feats // 2, dilation=3),
            nn.Conv2d(n_feats // 2, n_feats // 2, 1, 1, 0)
        )
        self.X5 = nn.Conv2d(n_feats // 2, n_feats // 2, 5, 1, 5 // 2, groups=n_feats // 2)

        self.X7 = nn.Conv2d((n_feats * 3) // 8, (n_feats * 3) // 8, 7, 1, 7 // 2, groups=(n_feats * 3) // 8)
        self.LKA7 = nn.Sequential(
            nn.Conv2d((n_feats * 3) // 8, (n_feats * 3) // 8, 7, 1, 7 // 2, groups=(n_feats * 3) // 8),
            nn.Conv2d((n_feats * 3) // 8, (n_feats * 3) // 8, 9, 1, (9 // 2) * 4,
                      groups=(n_feats * 3) // 8, dilation=4),
            nn.Conv2d((n_feats * 3) // 8, (n_feats * 3) // 8, 1, 1, 0)
        )

        self.proj_last = nn.Sequential(nn.Conv2d(n_feats, n_feats, 1, 1, 0))
        self.gate = nn.Conv2d(n_feats, n_feats, 1)
        self.proj_2 = ConvModule(n_feats, n_feats)

        self.act_value = nn.SiLU()
        self.act_gate = nn.SiLU()
        self.scale = nn.Parameter(torch.zeros((1, n_feats, 1, 1)), requires_grad=True)

    def forward(self, x):
        shortcut = x.clone()
        x = self.norm(x)
        x = self.proj_first(x)
        a, x = torch.chunk(x, 2, dim=1)

        total_channels = x.size(1)
        channels_1 = total_channels // 8
        channels_2 = total_channels // 2
        channels_3 = total_channels - channels_1 - channels_2

        a_1, a_2, a_3 = torch.split(x, [channels_1, channels_2, channels_3], dim=1)

        a = torch.cat([
            self.LKA3(a_1) * self.X3(a_1),
            self.LKA5(a_2) * self.X5(a_2),
            self.LKA7(a_3) * self.X7(a_3)
        ], dim=1)

        Fg = self.gate(x)
        x = self.proj_2(self.act_gate(Fg) * self.act_gate(a)) * self.scale + shortcut
        return x

from collections import OrderedDict
import torch
import torch.nn as nn
import torch.nn.functional as F

def BasicConv(filter_in, filter_out, kernel_size, stride=1, pad=None):
    if not pad:
        pad = (kernel_size - 1) // 2 if kernel_size else 0
    else:
        pad = pad
    return nn.Sequential(OrderedDict([
        ("conv", nn.Conv2d(filter_in, filter_out, kernel_size=kernel_size, stride=stride, padding=pad, bias=False)),
        ("bn", nn.BatchNorm2d(filter_out)),
        ("relu", nn.ReLU(inplace=True)),
    ]))


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, filter_in, filter_out):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(filter_in, filter_out, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(filter_out, momentum=0.1)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(filter_out, filter_out, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(filter_out, momentum=0.1)

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        out += residual
        out = self.relu(out)

        return out

class F1(nn.Module):
    def __init__(self, channel_dim=512):
        super(F1, self).__init__()

        self.channel_dim = channel_dim
        mid_dim = self.channel_dim // 2

        # 两个分支的权重映射卷积
        self.branch1_mapper = BasicConv(self.channel_dim, mid_dim, 1, 1)
        self.branch2_mapper = BasicConv(self.channel_dim, mid_dim, 1, 1)

        # 将两个分支的权重组合生成 softmax 权重
        self.merge_weight_layer = nn.Conv2d(mid_dim * 2, 2, kernel_size=1, stride=1)

        # 融合后的卷积
        self.refine_conv = BasicConv(self.channel_dim, self.channel_dim, 3, 1)

        # shortcut 融合卷积（两个输入拼接后降维）
        self.shortcut_conv = BasicConv(self.channel_dim * 2, self.channel_dim, 3, 1)


    def forward(self, feat_a, feat_b):


        skip_feat = torch.cat((feat_a, feat_b), dim=1)
        skip_feat = self.shortcut_conv(skip_feat)


        weight_a = self.branch1_mapper(feat_a)
        weight_b = self.branch2_mapper(feat_b)


        weight_cat = torch.cat((weight_a, weight_b), dim=1)
        soft_weights = self.merge_weight_layer(weight_cat)
        soft_weights = F.softmax(soft_weights, dim=1)


        fused_feat = feat_a * soft_weights[:, 0:1, :, :] + \
                     feat_b * soft_weights[:, 1:2, :, :]


        out_feat = self.refine_conv(fused_feat)


        final_out = out_feat + skip_feat

        return final_out



class LayerNorm(nn.Module):
    def __init__(self, normalized_shape, eps=1e-6, data_format="channels_last"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.data_format = data_format
        if self.data_format not in ["channels_last", "channels_first"]:
            raise NotImplementedError
        self.normalized_shape = (normalized_shape,)

    def forward(self, x):
        if self.data_format == "channels_last":
            return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        elif self.data_format == "channels_first":
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            x = self.weight[:, None, None] * x + self.bias[:, None, None]
            return x

class GSAU(nn.Module):
    def __init__(self, n_feats):
        super().__init__()
        i_feats = n_feats * 2
        self.norm = LayerNorm(n_feats, data_format='channels_first')
        self.Conv1 = nn.Conv2d(n_feats, i_feats, 1, 1, 0)
        self.DWConv1 = nn.Conv2d(n_feats, n_feats, 7, 1, 7 // 2, groups=n_feats)
        self.Conv2 = nn.Conv2d(n_feats, n_feats, 1, 1, 0)
        self.scale = nn.Parameter(torch.zeros((1, n_feats, 1, 1)), requires_grad=True)

    def forward(self, x):
        shortcut = x.clone()
        x = self.Conv1(self.norm(x))
        a, x = torch.chunk(x, 2, dim=1)
        x = x * self.DWConv1(a)
        x = self.Conv2(x)
        return x * self.scale + shortcut

class ElementScale(nn.Module):
    def __init__(self, embed_dims, init_value=0., requires_grad=True):
        super(ElementScale, self).__init__()
        self.scale = nn.Parameter(
            init_value * torch.ones((1, embed_dims, 1, 1)),
            requires_grad=requires_grad
        )

    def forward(self, x):
        return x * self.scale

class ChannelAggregationFFN(nn.Module):
    def __init__(self, embed_dims, ffn_ratio=4., kernel_size=3, ffn_drop=0.):
        super(ChannelAggregationFFN, self).__init__()
        self.embed_dims = embed_dims
        feedforward_channels = int(embed_dims * ffn_ratio)
        self.feedforward_channels = feedforward_channels

        self.fc1 = nn.Conv2d(
            in_channels=embed_dims,
            out_channels=self.feedforward_channels,
            kernel_size=1
        )

        self.dwconv = nn.Conv2d(
            in_channels=self.feedforward_channels,
            out_channels=self.feedforward_channels,
            kernel_size=kernel_size,
            stride=1,
            padding=kernel_size // 2,
            bias=True,
            groups=self.feedforward_channels
        )

        self.act = nn.GELU()

        self.fc2 = nn.Conv2d(
            in_channels=feedforward_channels,
            out_channels=embed_dims,
            kernel_size=1
        )

        self.drop = nn.Dropout(ffn_drop)

        self.decompose = nn.Conv2d(
            in_channels=self.feedforward_channels,
            out_channels=1,
            kernel_size=1
        )

        self.sigma = ElementScale(
            self.feedforward_channels,
            init_value=1e-5,
            requires_grad=True
        )

        self.decompose_act = nn.GELU()

    def feat_decompose(self, x):
        Temp = self.decompose(x)
        Temp = self.decompose_act(Temp)
        Temp = x - Temp
        Temp = self.sigma(Temp)
        x = x + Temp
        return x

    def forward(self, x):
        x = self.fc1(x)
        x = self.dwconv(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.feat_decompose(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x

class MLP(nn.Module):
    def __init__(self, dims):
        super().__init__()
        self.CA = ChannelAggregationFFN(dims)
        self.SA = GSAU(dims)

    def forward(self, x):
        shortcut = x.clone()
        x_s = self.SA(x) + shortcut
        return x_s
