import torch
import torch.nn as nn

import CBAM


from segformer import *
from typing import Tuple

# y = F.interpolate(y, size=[input_size[2], input_size[3]], mode='bilinear', align_corners=False)
class ConvModule(nn.Module):#3*3
    def __init__(self, c1, c2):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, 3, 1, 1, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.activate = nn.ReLU(True)
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.activate(self.bn(self.conv(x)))
class ConvModule1(nn.Module):#3*3
    def __init__(self, c1, c2):
        super().__init__()
        self.conv = nn.Conv2d(c1, c2, 3, 1, 1, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.activate = nn.ReLU(True)
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.activate(self.bn(self.conv(x)))
class MyDecoderLayer(nn.Module):#[[64, 64],[128, 128],[320, 256],[512, 512]]
    def __init__(self, in_out_chan,n_class=9, is_last=False,is_First=False):
        super().__init__()
        dims = in_out_chan[0]
        out_dim = in_out_chan[1]
        if is_First:
            self.CBAM=CBAM.CBAM(out_dim )
        if not is_last and not is_First:
            # self.conv1=nn.Conv2d(in_out_chan[0], in_out_chan[1], kernel_size=1, stride=1, padding=0)#x2转换通道数
            self.conv1 = ConvModule1(in_out_chan[0], in_out_chan[1])#x2转换通道数
            self.conv2 = nn.Conv2d(in_out_chan[1] * 2, in_out_chan[1], kernel_size=1, stride=1, padding=0)  # x1转换通道数
            self.up = nn.UpsamplingBilinear2d(scale_factor=2)  # x1上采样改变尺寸

            self.conv3 = ConvModule(in_out_chan[1]*3 , in_out_chan[1])#高低级特征融合
            self.conv4 = ConvModule(in_out_chan[1], in_out_chan[1])  #高低级特征融合
            # transformer decoder
            self.CBAM = CBAM.CBAM(out_dim)
            # 上采样
            self.last_layer = None
            self.SAFM =SAFM(out_dim)  # 融合
            self.CREM =CREM(out_dim, out_dim // 2, out_dim)  # 跳跃连接增强边缘
            self.conv_sub = nn.Sequential(
                nn.Conv2d(in_out_chan[1], in_out_chan[1], 3, padding=1, bias=False),
                nn.BatchNorm2d(in_out_chan[1]),
                nn.ReLU(inplace=True),)
            #最后一层输出为NOne
        else:
            #上采样
            self.conv1 = ConvModule(in_out_chan[0], in_out_chan[1])
            self.conv2 = nn.Conv2d(in_out_chan[1]*2 , in_out_chan[1], kernel_size=1, stride=1, padding=0)  # x1转换通道数
            self.up = nn.UpsamplingBilinear2d(scale_factor=2)  # x1上采用
            self.CREM = CREM(out_dim, out_dim // 2, out_dim)  # 跳跃连接增强边缘
            self.conv3 = ConvModule(in_out_chan[1]*3, in_out_chan[1])
            # transformer decoder
            self.CBAM = CBAM.CBAM(out_dim )
            self.SAFM = SAFM(out_dim)#门控
            self.last_layer = nn.Conv2d(out_dim, n_class, 1)
            self.conv4 = ConvModule(in_out_chan[1], in_out_chan[1])  # 高低级特征融合
            self.conv_sub = nn.Sequential(
                nn.Conv2d(in_out_chan[1], in_out_chan[1], 3, padding=1, bias=False),
                nn.BatchNorm2d(in_out_chan[1]),
                nn.ReLU(inplace=True), )
            # self.last_layer = Non
       

        def init_weights(self): #初始化模型参数
            for m in self.modules():
                if isinstance(m, nn.Linear):
                    nn.init.xavier_uniform_(m.weight)
                    if m.bias is not None:
                        nn.init.zeros_(m.bias)
                elif isinstance(m, nn.LayerNorm):
                    nn.init.ones_(m.weight)
                    nn.init.zeros_(m.bias)
                elif isinstance(m, nn.Conv2d):
                    nn.init.xavier_uniform_(m.weight)
                    if m.bias is not None:
                        nn.init.zeros_(m.bias)

        init_weights(self)
      
    def forward(self, x1, x2=None):#x1主输入特征，x2辅助输入特征
        if x2 is not None:
            #1.边缘增强,通道转换：
            x2 = self.conv1(x2)  # 转换通道
            x2_Final = self.CREM(x2)#MEEM里面已经有残差

            x1_G=self.conv2(x1)#x1只转换通道
            x1_up= self.up(x1_G)#尺寸完全相同
            x1_up_c=self.up(x1)#只改变尺寸
            x2_AG=self.SAFM(x2_Final,x1_up)+x2_Final#x2AG:主体加强版

            cat_x=torch.cat((x1_up_c,x2_AG),dim=1)
            fusion_x=self.conv3(cat_x)

            x_sub=torch.abs(x2_Final - x2)#加强边缘，skip与x1的差值加强
            x_att = torch.sigmoid(self.conv_sub(x_sub))
            fusion_x = (fusion_x * x_att) + fusion_x
            #如果存在最后一层
            if self.last_layer:
                #上采样饼通过最后一层卷积层得到输出
                out = self.last_layer(self.up(fusion_x))
            else:
                # #只上采样
                out = self.CBAM(fusion_x)
        else:
            out = self.CBAM(x1)
        return out

class MISSFormer(nn.Module):
    def __init__(self, num_classes=9, token_mlp_mode="mix_skip", encoder_pretrained=True):
        super().__init__()
        d_base_feat_size = 14 #16 for 512 inputsize   7for 224
        in_out_chan = [[64, 64],[128, 128],[320, 256],[512, 512]]

        dims, layers = [[64, 128, 320, 512], [2, 2, 2, 2]]

        self.backbone = MiT(224, dims, layers,token_mlp_mode)#mode为mix_skip
        self.decoder_3= MyDecoderLayer( in_out_chan[3], n_class=num_classes,is_First=True)
        self.decoder_2= MyDecoderLayer(in_out_chan[2],  n_class=num_classes)
        self.decoder_1= MyDecoderLayer( in_out_chan[1], n_class=num_classes)
        self.decoder_0= MyDecoderLayer(in_out_chan[0], n_class=num_classes, is_last=True)

        
    def forward(self, x):
        #---------------Encoder-------------------------
        if x.size()[1] == 1:
            x = x.repeat(1,3,1,1)

        encoder = self.backbone(x)

        bridge = encoder #list
        tmp_3 = self.decoder_3(bridge[3])
        tmp_2 = self.decoder_2(tmp_3, bridge[2])
        tmp_1 = self.decoder_1(tmp_2, bridge[1])
        tmp_0 = self.decoder_0(tmp_1, bridge[0])

        return tmp_0

import torch
from torch import nn


class BorderAmplifier(nn.Module):  #
    def __init__(self, in_channels, norm_layer, act_layer):
        super().__init__()
        self.edge_gate = nn.Sequential(  # 输出卷积 + 门控
            nn.Conv2d(in_channels, in_channels, kernel_size=1, bias=False),
            norm_layer(in_channels),
            nn.Sigmoid()
        )
        self.blur_pool = nn.AvgPool2d(kernel_size=3, stride=1, padding=1)

    def forward(self, feat):
        smoothed = self.blur_pool(feat)
        edge_feat = feat - smoothed
        edge_feat = self.edge_gate(edge_feat)
        return feat + edge_feat


class CREM(nn.Module):
    def __init__(
        self,
        in_channels,
        inner_channels,
        out_channels,
        num_stages=4,
        norm_layer=nn.BatchNorm2d,
        act_layer=nn.ReLU
    ):
        super().__init__()

        self.in_channels = in_channels
        self.inner_channels = inner_channels
        self.num_stages = num_stages  # 原来的 width


        self.input_proj = nn.Sequential(
            nn.Conv2d(in_channels, inner_channels, kernel_size=1, bias=False),
            norm_layer(inner_channels),
            nn.Sigmoid()
        )

        self.stage_pool = nn.AvgPool2d(kernel_size=3, stride=1, padding=1)

        self.stage_convs = nn.ModuleList()
        self.edge_blocks = nn.ModuleList()


        for _ in range(num_stages - 1):
            self.stage_convs.append(
                nn.Sequential(
                    nn.Conv2d(inner_channels, inner_channels, kernel_size=1, bias=False),
                    norm_layer(inner_channels),
                    nn.Sigmoid()
                )
            )
            self.edge_blocks.append(BorderAmplifier(inner_channels, norm_layer, act_layer))


        self.output_proj = nn.Sequential(
            nn.Conv2d(inner_channels * num_stages, in_channels,
                      kernel_size=1, stride=1, padding=0, bias=False),
            norm_layer(in_channels),
            act_layer()
        )

    def forward(self, feat):

        inner_feat = self.input_proj(feat)
        identity = feat

        concat_feat = inner_feat


        for idx in range(self.num_stages - 1):
            inner_feat = self.stage_pool(inner_feat)
            inner_feat = self.stage_convs[idx](inner_feat)
            enhanced = self.edge_blocks[idx](inner_feat)
            concat_feat = torch.cat([concat_feat, enhanced], dim=1)

        out = self.output_proj(concat_feat)

        return out+identity


class ConvBlock3x3(nn.Module):  # 3x3 卷积模块（改名）
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv_layer = nn.Conv2d(in_channels, out_channels, 3, 1, 1, bias=False)
        self.norm_layer = nn.BatchNorm2d(out_channels)
        self.activation = nn.ReLU(inplace=True)

    def forward(self, feat: torch.Tensor) -> torch.Tensor:
        return self.activation(self.norm_layer(self.conv_layer(feat)))


def count_trainable_parameters(model: nn.Module) -> float:
    total_millions = sum(p.numel() for p in model.parameters() if p.requires_grad) / 1e6
    return total_millions


class ChannelGlobalExtractor(nn.Module):
    def __init__(self, channels=None):
        super().__init__()

        self.avg_channel_pool = self._avg_channel_pool
        self.max_channel_pool = self._max_channel_pool
        self.fusion_proj = nn.Sequential(
            nn.Conv2d(2, 1, kernel_size=1, stride=1),
            nn.BatchNorm2d(1)
        )

    def _avg_channel_pool(self, feat: torch.Tensor) -> torch.Tensor:
        return feat.mean(dim=1, keepdim=True)

    def _max_channel_pool(self, feat: torch.Tensor) -> torch.Tensor:
        return feat.max(dim=1, keepdim=True)[0]

    def forward(self, feat: torch.Tensor) -> torch.Tensor:
        feat_clone = feat.clone()
        avg_map = self.avg_channel_pool(feat)
        max_map = self.max_channel_pool(feat_clone)

        fused = torch.cat((avg_map, max_map), dim=1)
        weight_map = self.fusion_proj(fused)
        return weight_map


class SAFM(nn.Module):
    # Version 1
    def __init__(self, channels: int):
        super().__init__()
        self.gate_conv = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True)
        )

        self.feature_conv = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True)
        )

        self.attention_map_gen = nn.Sequential(
            nn.Conv2d(channels, 1, kernel_size=1, stride=1, padding=0, bias=True),
            nn.BatchNorm2d(1),
            nn.Sigmoid()
        )

        self.act = nn.ReLU(inplace=True)
        self.global_extractor = ChannelGlobalExtractor()

        self.proj_conv = nn.Conv2d(channels, channels, kernel_size=1)
        self.norm1 = nn.BatchNorm2d(channels)
        self.norm2 = nn.BatchNorm2d(channels)
        self.aux_conv_block = nn.Sequential(
            nn.Conv2d(in_channels=channels, out_channels=channels,
                      kernel_size=1, stride=1),
            nn.BatchNorm2d(channels)
        )
        self.fusion_conv = ConvBlock3x3(channels * 2, channels)

    def forward(self, feat: torch.Tensor, guide: torch.Tensor) -> torch.Tensor:
        residual = feat.clone()

        guide_map = self.global_extractor(guide)

        feat_sigmoid = torch.sigmoid(feat)
        guide_modulated = feat_sigmoid * guide_map
        guide_sigmoid = torch.sigmoid(guide_modulated)
        feat = guide_sigmoid * feat

        gate_feat = self.gate_conv(guide_modulated)
        feat_proj = self.feature_conv(feat)
        attn_weight = self.attention_map_gen(self.act(feat_proj + gate_feat))

        out = feat * attn_weight
        out = out + residual
        return out