import torch
import torch.nn as nn
import pytorch_wavelets
from pytorch_wavelets import DWTForward

# pip install pytorch_wavelets==1.3.0
# pip install PyWavelets

class HWD(nn.Module):
    # 初始化函数
    def __init__(self, in_ch, out_ch):
        super(HWD, self).__init__()
        # 定义离散小波变换(DWT)前向操作，参数J表示分解级别为1，mode设置边界处理方式为零填充，wave指定使用Haar小波
        self.wt = DWTForward(J=1, mode='zero', wave='haar')
        # 定义卷积-批归一化-激活层序列
        self.conv_bn_relu = nn.Sequential(
            # 添加2D卷积层，输入通道数是原通道数的4倍（因为经过DWT后会产生4个子带），输出通道数为out_ch
            nn.Conv2d(in_ch * 4, out_ch, kernel_size=1, stride=1),
            # 批量归一化层，对out_ch个特征图进行归一化
            nn.BatchNorm2d(out_ch),
            # ReLU激活函数，inplace=True表示直接在输入数据上进行修改以节省内存
            nn.ReLU(inplace=True),
        )
    # 前向传播函数
    def forward(self, x):
        # 对输入x执行DWT，得到低频分量yL和高频分量yH
        yL, yH = self.wt(x)     # torch.Size([1, 3, 32, 32]) torch.Size([1, 3, 32, 32])

        # 从高频分量yH中提取出水平细节系数
        y_HL = yH[0][:, :, 0, ::]   # torch.Size([1, 3, 32, 32])
        # 从高频分量yH中提取出垂直细节系数
        y_LH = yH[0][:, :, 1, ::]   # torch.Size([1, 3, 32, 32])
        # 从高频分量yH中提取出对角线细节系数
        y_HH = yH[0][:, :, 2, ::]   # torch.Size([1, 3, 32, 32])


        # 将低频分量yL与三个方向的高频分量沿着通道维度拼接
        x = torch.cat([yL, y_HL, y_LH, y_HH], dim=1)    # torch.Size([1, 12, 32, 32])

        # 拼接后的张量通过定义好的conv_bn_relu序列
        x = self.conv_bn_relu(x)
        # 返回最终输出
        return x
